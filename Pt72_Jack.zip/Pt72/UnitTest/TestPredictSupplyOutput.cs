﻿using NUnit.Framework;
using ProductionProdictSvc;

namespace UnitTest
{
    [TestFixture]
    public class TestPredictSupplyOutput
    {
        [TestCase(10, 2, 10, 1)]
        [TestCase(10, 1, 10, 1)]
        [TestCase(10, 0.5, 10, 2)]
        [TestCase(10, 0.3, 10, 3)]
        [TestCase(20, 0.3, 10, 6)]
        public void TestCalcStartPeakPeriod(int output, decimal r, int p, int expected)
        {
            var predictSupplyOutput = new PredictSupplyOutput();
            var input = new Input(output, p, r, 1);
            var actual = predictSupplyOutput.CalcStartPeakPeriod(input);

            Assert.IsTrue(actual == expected);
        }

        [TestCase(10, 2, 10, 10, 100)]
        [TestCase(10, 0.5, 10, 10, 150)]
        [TestCase(10, 0.3, 10, 10, 210)]
        [TestCase(20, 0.3, 10, 10, 750)]
        public void TestCalcPeakOutput(int output, decimal r, int p, int d, decimal expected)
        {
            var predictSupplyOutput = new PredictSupplyOutput();
            var input = new Input(output,p,r,d);
            var actual = predictSupplyOutput.CalcPeakOutput(input);

            Assert.IsTrue(actual == expected);
        }
    }
}
