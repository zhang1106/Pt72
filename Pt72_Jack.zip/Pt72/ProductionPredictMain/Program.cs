﻿using System;
using ProductionProdictSvc;
using StructureMap;

namespace ProductionPredictMain
{
    class Program
    {
        static void Main(string[] args)
        {
            var cmd = 'C';
            while (cmd != 'X')
            {
                try
                {
                    var container = Register();
                    var predictSupplyOutput = container.GetInstance<IPredictSupplyOutput>();

                    Console.WriteLine("output=");
                    var output = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("r=");
                    var r = Convert.ToDecimal(Console.ReadLine());
                    Console.WriteLine("p=");
                    var p = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("d=");
                    var d = Convert.ToInt32(Console.ReadLine());
                    var input = new Input(output,p,r,d);
                    var peakDay = predictSupplyOutput.CalcStartPeakPeriod(input);
                    Console.WriteLine($"The first peak day will be the {peakDay*p}th day");
                    var peakOutput = predictSupplyOutput.CalcPeakOutput(input);
                    Console.WriteLine($"Peak output will be {peakOutput} barrels");
                }
                catch (Exception e)
                {
                     Console.WriteLine(e.Message);
                }
                cmd = Console.ReadKey().KeyChar;
            }
          
        }

        static Container Register()
        {
            return new Container(_ =>
            {
                _.For<IPredictSupplyOutput>().Use<PredictSupplyOutput>();
            });
        }
    }
}
