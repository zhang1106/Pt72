﻿using System;

namespace ProductionProdictSvc
{
    /// <summary>
    /// The implementation is based on the following understandings and analysis:
    /// 1) All new wells will have the same init output in barrels
    /// 2) All new wells takes the same period time (P) in days to finish
    /// 3) All wells will reduce output by the same amount every day
    /// 4) Given the above 3 conditions, given the period P, it is easy to prove that peak time can only occur on the days when drills are finished.
    /// 5) The peak output will be the sum of new wells' output and the output of still live wells from previous periods.
    ///    Total = d*outpout + d*(output-p*r*(n-1)) + ...  
    /// </summary>
    public class PredictSupplyOutput: IPredictSupplyOutput
    {
        /// <summary>
        /// Given that production will be reduced between the period point, the perk day will have to be 
        /// on the day of a finished period, this method is to calculate the nth period which will have peak output
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public int CalcStartPeakPeriod(Input input)
        {
            string validateMsg;
            if (!input.IsValid(out validateMsg))
            {
                throw new ArgumentException(validateMsg);
            }

            var livingPeriod = (int)(input.Output / input.Reduction) / input.Period;
            if (livingPeriod < 1) livingPeriod = 1;
            return livingPeriod;
        }

        /// <summary>
        /// The peak output will include the output from the newly finished wells and the still-live wells
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public decimal CalcPeakOutput(Input input)
        {
            string validateMsg;
            if (!input.IsValid(out validateMsg))
            {
                throw new ArgumentException(validateMsg);
            }

            var livingPeriod = CalcStartPeakPeriod(input);
            decimal peakProduction = input.Drills * input.Output;
            for (var i = livingPeriod-1; i > 0; i--)
            {
                var prod = input.Drills * (input.Output - input.Reduction * i * input.Period);
                peakProduction += prod;
            }
            return peakProduction;
        }
      
    }
}
