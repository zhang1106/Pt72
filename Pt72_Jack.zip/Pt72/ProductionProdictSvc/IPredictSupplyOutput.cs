﻿namespace ProductionProdictSvc
{
    public interface IPredictSupplyOutput
    {
        int CalcStartPeakPeriod(Input input);
        decimal CalcPeakOutput(Input input);
    }
}
