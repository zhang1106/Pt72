﻿namespace ProductionProdictSvc
{
    public class Input
    {
        /// <summary>
        /// This is the input parameters
        /// </summary>
        /// <param name="output">output of a drilled well</param>
        /// <param name="p">days needed to finish a drill</param>
        /// <param name="r">reduction of barrels of a day for a well</param>
        /// <param name="d">number of drills</param>
        public Input(int output, int p, decimal r, int d)
        {
            Output = output;
            Period = p;
            Reduction = r;
            Drills = d;
        }
        public int Drills { get; }
        public int Output { get; }
        public decimal Reduction { get;}
        public int Period { get; }

        /// <summary>
        /// validate the input parameters
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public bool IsValid(out string msg)
        {
            if (Output <= 0)
            {
                msg = ($"The parameter 'Output' should be greater than 0. Value '{Output}' is Invalid.");
                return false;
            }
            if (Reduction <= 0)
            {
                msg = $"The parameter 'Reduction' should be greater than 0. Value '{Reduction}' is Invalid.";
                return false;
            }

            if (Period <= 0)
            {
                msg = $"The parameter 'Period' should be greater than 0. Value '{Period}' is Invalid.";
                return false;
            }

            if (Drills <= 0)
            {
                msg = $"The parameter 'Drills' should be greater than 0. Value '{Drills}' is Invalid.";
                return false;
            }

            msg = "Ok";
            return true;
        }
    }
}
